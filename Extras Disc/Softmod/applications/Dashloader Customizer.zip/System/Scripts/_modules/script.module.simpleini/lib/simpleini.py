'''
	SimpleIni, script by Rocky5

	Usage:
		import simpleini

		# Load file
		ini = simpleini.load('config.ini')

		# Read
		name   = simpleini.get(ini, 'Section', 'Key')
		width  = simpleini.getint(ini, 'Video', 'Width')
		height = simpleini.getfloat(ini, 'Video', 'Height')

		# Write and save
		simpleini.set(ini, 'Audio', 'Volume', '90')
		simpleini.write(ini)

		# Create file
		ini = simpleini.parse('', 'config.ini')

		# Write a bare comment or blank line
		simpleini.set(ini, '', '', '# My config file')
		simpleini.set(ini, '', '', '')

		# Write bare key = value line
		simpleini.set(ini, '', 'version', '1')

		# Write sectioned key = value line (section header casing follows what you pass in)
		simpleini.set(ini, 'Video', 'Width', '1280')
		simpleini.set(ini, 'Video', 'Height', '720')
		simpleini.write(ini)

		Output Example:
			version = 1
			[Video]
			width = 1280
			height = 720
'''
from collections import OrderedDict

# Helpers
def get(ini, section, key, default = None):
	section = section.lower()
	key = key.lower()

	try:
		return ini['data'][section][0][key][0]
	except:
		return default


def getfloat(ini, section, key, default = None):
	try:
		return float(get(ini, section, key))
	except:
		return default


def getint(ini, section, key, default = None):
	try:
		return int(get(ini, section, key))
	except:
		return default


def getlist(ini, section, key):
	section = section.lower()
	key = key.lower()

	try:
		result = []
		for block in ini['data'][section]:
			if key in block:
				result.extend(block[key])
		return result
	except:
		return []


def getsection(ini, section):
	section = section.lower()
	result = []

	blocks = ini['data'].get(section, [])
	for block in blocks:
		for key, values in block.items():
			for v in values:
				result.append(v)

	return result


def items(ini, section):
	section = section.lower()
	merged = {}

	for block in ini['data'].get(section, []):
		for key, values in block.items():
			merged.setdefault(key, []).extend(values)

	return merged.items()


def sections(ini):
	return list(ini['order'])


# Edit
def append(ini, section, key, value):
	section_lower = section.lower()
	key = key.lower()

	if section_lower not in ini['data']:
		ini['data'][section_lower] = [OrderedDict()]
		ini['order'].append(section_lower)
		ini['casing'][section_lower] = section

	ini['data'][section_lower][-1].setdefault(key, []).append(value)


def remove_option(ini, section, key):
	section = section.lower()
	key = key.lower()

	if section in ini['data']:
		for block in ini['data'][section]:
			if key in block:
				del block[key]


def remove_section(ini, section):
	section = section.lower()

	if section in ini['data']:
		del ini['data'][section]
	if section in ini['order']:
		ini['order'].remove(section)
	if section in ini['casing']:
		del ini['casing'][section]


def set(ini, section, key, value):
	section_lower = section.lower()
	key = key.lower()

	if section_lower not in ini['data']:
		ini['data'][section_lower] = [OrderedDict()]
		ini['order'].append(section_lower)
		ini['casing'][section_lower] = section

	if section_lower == '' and key == '':
		ini['data'][section_lower][-1].setdefault('_raw_', []).append(value)
	else:
		ini['data'][section_lower][-1][key] = [value]


# Save
def write(ini, path = None):
	if path is None:
		path = ini['path']
	with open(path, 'w') as file:
		last_section = ini['order'][-1] if ini['order'] else None
		for section in ini['order']:
			not_first_line = False
			for block in ini['data'][section]:
				if not block:
					continue
				not_first_line = True
				if section != '':
					file.write('[{}]\n'.format(ini['casing'].get(section, section)))
				for key, values in block.items():
					for value in values:
						if key == '_raw_':
							file.write(value + '\n')
						else:
							file.write('{} = {}\n'.format(key, value))
			if not_first_line and section != last_section:
				file.write('\n')


# Parse
def parse(text, path = ''):
	data = {'': [OrderedDict()]}
	order = ['']
	casing = {'': ''}
	current = data[''][0]

	for line in text.splitlines():
		raw = line.rstrip('\r\n')
		stripped = raw.strip()

		if not stripped or stripped.startswith(';') or stripped.startswith('#'):
			continue

		if stripped.startswith('[') and stripped.endswith(']'):
			original = stripped[1:-1].strip()
			section = original.lower()

			if section not in data:
				data[section] = []
				order.append(section)
				casing[section] = original

			data[section].append(OrderedDict())
			current = data[section][-1]
			continue

		if '=' in stripped and current is not None:
			key, value = stripped.split('=', 1)
			key = key.strip().lower()
			value = value.strip()

			current.setdefault(key, []).append(value)
			continue

		if current is not None:
			key = '_bare_{}'.format(len(current))
			current.setdefault(key, []).append(stripped)

	return {'data': data, 'order': order, 'casing': casing, 'path': path}


# Load
def load(path):
	data = {'': [OrderedDict()]}
	order = ['']
	casing = {'': ''}
	current = data[''][0]

	with open(path, 'r') as file:
		for line in file:
			raw = line.rstrip('\r\n')
			stripped = raw.strip()

			if not stripped or stripped.startswith(';') or stripped.startswith('#'):
				continue

			if stripped.startswith('[') and stripped.endswith(']'):
				original = stripped[1:-1].strip()
				section = original.lower()

				if section not in data:
					data[section] = []
					order.append(section)
					casing[section] = original

				data[section].append({})
				current = data[section][-1]
				continue

			if '=' in stripped and current is not None:
				key, value = stripped.split('=', 1)
				key = key.strip().lower()
				value = value.strip()

				current.setdefault(key, []).append(value)
				continue

			if current is not None:
				key = '_bare_{}'.format(len(current))
				current.setdefault(key, []).append(stripped)

	return {'data': data, 'order': order, 'casing': casing, 'path': path}