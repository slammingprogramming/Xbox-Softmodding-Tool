from xbmc import getLocalizedString

DISABLE_LABEL = getLocalizedString(1223)

XBE_VERSION = '2.2.2'
XBE_SIGNATURE = 'Dashloader.ini'

NEW_XBE = 'Q:/system/scripts/dashloader.xbe'
XBE_PATH_SOFTMOD = 'X:/nkpatcher/dashloader/default.xbe'
XBE_PATH_HARDMOD = 'C:/evoxdash.xbe'

SAVE_PATH_NEW_SOFTMOD = 'X:/nkpatcher/dashloader/'
SAVE_PATH_NEW_HARDMOD = 'C:/'
SAVE_PATH_LEGACY_SOFTMOD = 'E:/UDATA/21585554/000000000000/nkpatcher settings/dashloader/'
SAVE_PATH_LEGACY_HARDMOD = 'C:/Dashloader/'

CFG_MAP = {
	'buttons_a': 'A_Button_Dash.cfg',
	'buttons_b': 'B_Button_Dash.cfg',
	'buttons_x': 'X_Button_Dash.cfg',
	'buttons_y': 'Y_Button_Dash.cfg',
	'buttons_black': 'Black_Button_Dash.cfg',
	'buttons_white': 'White_Button_Dash.cfg',
	'buttons_start': 'Start_Button_Dash.cfg',
	'buttons_back': 'Back_Button_Dash.cfg',
}

CUSTOM_CFG_MAP = {
	'dashboard_path': 'Custom_Dash.cfg',
	'recovery_path': 'Custom_Recovery.cfg',
}

# Mapping from cfg prop name to INI section and key
CFG_TO_INI = {
	'buttons_a': ('Buttons', 'A'),
	'buttons_b': ('Buttons', 'B'),
	'buttons_x': ('Buttons', 'X'),
	'buttons_y': ('Buttons', 'Y'),
	'buttons_black': ('Buttons', 'Black'),
	'buttons_white': ('Buttons', 'White'),
	'buttons_start': ('Buttons', 'Start'),
	'buttons_back': ('Buttons', 'Back'),
	'dashboard_path': ('Dashboard', 'Path'),
	'recovery_path': ('Recovery', 'Path'),
}

INI_TEMPLATE = '''[UI]
Enabled = 1
SingleColour = 0
ButtonDelay = 1000
LaunchDelay = 700

[Logging]
Enabled = 1

[Buttons]
A = 
B = 
X = 
Y = 
White = 
Black = 
Back = 
Start = 

[Recovery]
Path = 

[Dashboard]
Path = 

[VirtualDrive]
ISOKernelPatch = 0
DismountISOonIGR = 0
'''
