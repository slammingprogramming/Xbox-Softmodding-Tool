'''
	Dashloader Customizer Script by Rocky5

	Actions:
		load:
			Reads config file and populates all window properties and skin settings.
			Example:
				Call this on window open.
				RunScript(Special://scripts/dashloader.py,load)

		save:
			Saves current state to config file.
			Example:
				Pass the key as the second argument.
				Toggles read their value from Skin.HasSetting.
				RunScript(Special://scripts/dashloader.py,save,<key>)

		browse:
			Opens an XBE file browser, sets the selected path as a window property and saves.
			Example:
				Pass the key as the second argument.
				Use custom_dashloader_path to set a custom dashloader XBE location.
				RunScript(Special://scripts/dashloader.py,browse,<key>)

		numeric:
			Opens a numeric input dialog pre-filled with the current value, sets the result as a window property and saves.
			Example:
				Pass the key as the second argument.
				RunScript(Special://scripts/dashloader.py,numeric,<key>)

		exit:
			Prompts the user to restart the xbox.
			Example:
				RunScript(Special://scripts/dashloader.py,exit)

	Window Properties (set on load):
		buttons_a, buttons_b, buttons_x, buttons_y
		buttons_black, buttons_white, buttons_start, buttons_back
		recovery_path, dashboard_path
		ui_buttondelay, ui_launchdelay
		newdashloader, hardmodded

	Skin Settings / Radiobuttons (set on load):
		ui_enabled, ui_singlecolour, logging_enabled
		virtualdrive_isokernelpatch, virtualdrive_dismountisoonigr

	XML Examples:
		<!-- Load on window open -->
		<onload>RunScript(Special://scripts/dashloader.py,load)</onload>

		<!-- Browse for XBE -->
		<onclick>RunScript(Special://scripts/dashloader.py,browse,buttons_a)</onclick>

		<!-- Toggle / Radio button -->
		<onclick>Skin.ToggleSetting(virtualdrive_isokernelpatch)</onclick>
		<onclick>RunScript(Special://scripts/dashloader.py,save,virtualdrive_isokernelpatch)</onclick>

		<!-- Numeric input -->
		<onclick>RunScript(Special://scripts/dashloader.py,numeric,ui_buttondelay)</onclick>

		<!-- Exit -->
		<onclick>RunScript(Special://scripts/dashloader.py,exit)</onclick>
'''
import sys, simpleini
from os import makedirs, remove
from os.path import dirname, isdir, isfile, join
from shutil import rmtree
from xbmc import executebuiltin, getCondVisibility, getLocalizedString, sleep
from xbmcgui import Dialog, Window
from shared import *

PROP_BUTTONS = ['buttons_a', 'buttons_b', 'buttons_x', 'buttons_y', 'buttons_black', 'buttons_white', 'buttons_start', 'buttons_back']
PROP_CUSTOM = ['recovery_path', 'dashboard_path']
PROP_TOGGLES = ['ui_enabled', 'ui_singlecolour', 'logging_enabled', 'virtualdrive_isokernelpatch', 'virtualdrive_dismountisoonigr']
PLACEHOLDER = 'E:\\Custom Path\\.xbe'


def set_property(key, value):
	Window(10000).setProperty(key.lower(), value)


def get_property(key):
	return Window(10000).getProperty(key.lower())


def skin_bool_setting(key):
	executebuiltin('Skin.SetBool({})'.format(key))


def skin_reset_setting(key):
	executebuiltin('Skin.Reset({})'.format(key))


def new_dashloader(xbe_path):
	if not isfile(xbe_path):
		return False
	try:
		with open(xbe_path, 'rb') as f:
			data = f.read()
		return XBE_SIGNATURE in data
	except Exception:
		return False


def is_dashloader_xbe(xbe_path):
	if not isfile(xbe_path):
		return False
	try:
		with open(xbe_path, 'rb') as f:
			data = f.read()
		return b'Dashloader' in data
	except Exception:
		return False


def check_xbe_version(mod_type, custom_xbe_path = ''):
	if custom_xbe_path:
		xbe_path = custom_xbe_path
	elif 'Softmod' in mod_type:
		xbe_path = XBE_PATH_SOFTMOD
	else:
		xbe_path = XBE_PATH_HARDMOD

	if 'Softmod' not in mod_type:
		set_property('hardmodded', '1')
	else:
		set_property('hardmodded', '')

	is_new = new_dashloader(xbe_path)
	set_property('newdashloader', '1' if is_new else '')
	return is_new


def get_save_path(mod_type, is_new):
	if 'Softmod' in mod_type:
		return SAVE_PATH_NEW_SOFTMOD if is_new else SAVE_PATH_LEGACY_SOFTMOD
	elif 'Custom' in mod_type:
		custom_xbe_path = get_property('CustomXBEPath')
		if custom_xbe_path:
			return dirname(custom_xbe_path).replace('\\', '/').rstrip('/') + '/'
		return SAVE_PATH_NEW_HARDMOD
	else:
		return SAVE_PATH_NEW_HARDMOD if is_new else SAVE_PATH_LEGACY_HARDMOD


def load_new(save_path):
	dashloaderini = join(save_path, 'Dashloader.ini')
	if not isfile(dashloaderini):
		clear_settings()
		save_new(save_path)

	ini = simpleini.load(dashloaderini)
	for section in simpleini.sections(ini):
		if not section:
			continue
		for key, values in simpleini.items(ini, section):
			value = values[0] if values else ''
			prop = section.lower() + '_' + key

			if prop in PROP_BUTTONS + PROP_CUSTOM:
				if not value or PLACEHOLDER in value:
					value = DISABLE_LABEL
			elif prop in PROP_TOGGLES:
				if value == '1':
					skin_bool_setting(prop)
				else:
					skin_reset_setting(prop)

			set_property(prop, value)


def load_legacy(save_path):
	try:
		rmtree('Q:/System/Systeminfo')
	except Exception:
		pass

	for prop, filename in CFG_MAP.items():
		cfg_path = join(save_path, filename)
		value = ''
		if isfile(cfg_path):
			with open(cfg_path, 'r') as f:
				value = f.readline().strip()
		if not value or PLACEHOLDER in value:
			value = DISABLE_LABEL
		set_property(prop, value)

	for prop, filename in CUSTOM_CFG_MAP.items():
		cfg_path = join(save_path, filename)
		value = ''
		if isfile(cfg_path):
			with open(cfg_path, 'r') as f:
				value = f.readline().strip()
		if not value or PLACEHOLDER in value:
			value = DISABLE_LABEL
		set_property(prop, value)

	for prop, flag in [
		('virtualdrive_dismountisoonigr', 'Disabled Virtual-ISO Dismount.bin'),
		('virtualdrive_isokernelpatch', 'Disable Virtual ISO Support.bin'),
	]:
		if isfile(join(save_path, flag)):
			set_property(prop, '0')
			skin_bool_setting(prop)
		else:
			set_property(prop, '1')
			skin_reset_setting(prop)


def clear_settings():
	for prop in PROP_BUTTONS + PROP_CUSTOM:
		set_property(prop, DISABLE_LABEL)

	for prop, default in [
		('ui_enabled', '1'),
		('ui_singlecolour', '0'),
		('logging_enabled', '1'),
		('virtualdrive_isokernelpatch', '0'),
		('virtualdrive_dismountisoonigr', '0'),
	]:
		set_property(prop, default)
		if default == '1':
			skin_bool_setting(prop)
		else:
			skin_reset_setting(prop)

	set_property('ui_buttondelay', '1000')
	set_property('ui_launchdelay', '700')


def load_file():
	mod_type = get_property('ModType')
	custom_xbe_path = get_property('CustomXBEPath')

	if not mod_type or get_property('ShowError') == '1':
		return

	is_new = check_xbe_version(mod_type, custom_xbe_path)

	if custom_xbe_path and not is_new:
		Dialog().ok(
			getLocalizedString(31300),
			getLocalizedString(31307),
			''
		)
		clear_settings()
		return

	save_path = get_save_path(mod_type, is_new)

	if is_new:
		load_new(save_path)
	else:
		load_legacy(save_path)


def save_new(save_path):
	ini_path = join(save_path, 'Dashloader.ini')
	ini = simpleini.parse(INI_TEMPLATE, ini_path)

	for section in simpleini.sections(ini):
		if not section:
			continue
		for key, values in simpleini.items(ini, section):
			prop = section.lower() + '_' + key
			value = get_property(prop)

			if prop in PROP_BUTTONS + PROP_CUSTOM and value == DISABLE_LABEL:
				value = ''
			elif prop in PROP_TOGGLES:
				value = '1' if getCondVisibility('Skin.HasSetting({})'.format(prop)) else '0'

			simpleini.set(ini, section, key, value)

	simpleini.write(ini, ini_path)


def save_legacy(save_path, key = ''):
	cfg_map_combined = dict(CFG_MAP)
	cfg_map_combined.update(CUSTOM_CFG_MAP)

	if key in cfg_map_combined:
		cfg_path = join(save_path, cfg_map_combined[key])
		value = get_property(key)
		if value and value != DISABLE_LABEL:
			with open(cfg_path, 'w') as f:
				f.write(value)
		elif isfile(cfg_path):
			remove(cfg_path)

	for prop, flag in [
		('virtualdrive_dismountisoonigr', 'Disabled Virtual-ISO Dismount.bin'),
		('virtualdrive_isokernelpatch', 'Disable Virtual ISO Support.bin'),
	]:
		flag_path = join(save_path, flag)
		if getCondVisibility('Skin.HasSetting({})'.format(prop)):
			with open(flag_path, 'w') as f:
				f.write('')
		elif isfile(flag_path):
			remove(flag_path)


def save_file(key = ''):
	mod_type = get_property('ModType')
	is_new = get_property('newdashloader') == '1'
	save_path = get_save_path(mod_type, is_new)

	if not mod_type:
		Dialog().ok(
			getLocalizedString(31308),
			getLocalizedString(31309),
			''
		)
		return

	if not isdir(save_path):
		try:
			makedirs(save_path)
		except OSError:
			pass

	if is_new:
		save_new(save_path)
	else:
		save_legacy(save_path, key)


def numeric(key = ''):
	current_value = get_property(key)

	label = getLocalizedString(31310)
	if 'ui_launchdelay' in key:
		label = getLocalizedString(31311)

	try:
		current = int(current_value)
	except ValueError:
		current = 1000

	result = Dialog().numeric(0, label, str(current))

	if result:
		set_property(key, result)
		save_file(key)


def browse(key = ''):
	selected = Dialog().browse(1, getLocalizedString(31312), 'files', '.xbe', False, False, '')

	if key == 'custom_dashloader_path':
		if selected and selected.endswith('.xbe'):
			if new_dashloader(selected) or is_dashloader_xbe(selected):
				set_property('CustomXBEPath', selected)
				executebuiltin('Skin.SetString(CustomXBEPath,{})'.format(selected))
				sleep(500)
				executebuiltin('RestartApp')
			else:
				Dialog().ok(
					getLocalizedString(31300),
					getLocalizedString(31313),
					''
				)
		return

	if selected and selected.endswith('.xbe'):
		set_property(key, selected)
	else:
		set_property(key, DISABLE_LABEL)

	save_file(key)


action = sys.argv[1] if len(sys.argv) > 1 else ''
key = sys.argv[2].lower() if len(sys.argv) > 2 else ''

if action == 'load':
	load_file()
elif action == 'save':
	save_file(key)
elif action == 'browse':
	browse(key)
elif action == 'numeric':
	numeric(key)
elif action == 'exit':
	if Dialog().yesno(getLocalizedString(31314), '', getLocalizedString(31315), '', getLocalizedString(106), getLocalizedString(107)):
		executebuiltin('ColdRestart')
