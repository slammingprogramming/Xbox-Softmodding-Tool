import re, sys, simpleini
from os import makedirs
from os.path import dirname, isdir, isfile, join
from shutil import copy2, rmtree
from xbmc import executebuiltin, getCondVisibility, getLocalizedString, getInfoLabel, sleep
from xbmcgui import Dialog, Window
from shared import *

ACTION = sys.argv[1] if len(sys.argv) > 1 else ''
CUSTOM_XBE_PATH = Window(10000).getProperty('customxbepath') or getInfoLabel('Skin.String(CustomXBEPath)')
STOCK_FOUND = isfile(XBE_PATH_SOFTMOD) or isfile(XBE_PATH_HARDMOD)


def show_changelog():
	executebuiltin('TextViewer(Special://scripts/changes.txt,Changelog)')


def get_installed_version(xbe_path):
	if not isfile(xbe_path):
		return None
	try:
		with open(xbe_path, 'rb') as f:
			data = f.read()
		match = re.search(r'Dashloader v(\d+\.\d+\.\d+)', data)
		if match:
			return tuple(int(x) for x in match.group(1).split('.'))
	except Exception:
		pass
	return None


def get_display_version():
	if STOCK_FOUND or (CUSTOM_XBE_PATH and isfile(CUSTOM_XBE_PATH)):
		xbe_path = CUSTOM_XBE_PATH if (CUSTOM_XBE_PATH and not STOCK_FOUND) else (XBE_PATH_SOFTMOD if isfile(XBE_PATH_SOFTMOD) else XBE_PATH_HARDMOD)
		installed_ver = get_installed_version(xbe_path)
		target_ver = tuple(int(x) for x in XBE_VERSION.split('.'))
		if installed_ver and installed_ver > target_ver:
			return '.'.join(str(x) for x in installed_ver)
	return XBE_VERSION

executebuiltin('Skin.SetString(dashloader_current_version,{})'.format(get_display_version()))


def get_current_xbe(mod_type):
	if 'Custom' in mod_type:
		return CUSTOM_XBE_PATH
	return XBE_PATH_SOFTMOD if 'Softmod' in mod_type else XBE_PATH_HARDMOD


def get_ini_save_path(mod_type):
	if 'Custom' in mod_type:
		return dirname(CUSTOM_XBE_PATH).replace('\\', '/').rstrip('/') + '/' if CUSTOM_XBE_PATH else SAVE_PATH_NEW_HARDMOD
	return SAVE_PATH_NEW_SOFTMOD if 'Softmod' in mod_type else SAVE_PATH_NEW_HARDMOD


def migrate_legacy(save_path, mod_type):
	new_save_path = get_ini_save_path(mod_type)
	if not isdir(new_save_path):
		try:
			makedirs(new_save_path)
		except OSError:
			pass
	ini_path = new_save_path + 'Dashloader.ini'
	ini = simpleini.parse(INI_TEMPLATE, ini_path)

	cfg_map_combined = dict(CFG_MAP)
	cfg_map_combined.update(CUSTOM_CFG_MAP)

	for prop, filename in cfg_map_combined.items():
		cfg_path = join(save_path, filename)
		if isfile(cfg_path):
			try:
				with open(cfg_path, 'r') as f:
					value = f.readline().strip()
				if value.endswith('.xbe'):
					section, key = CFG_TO_INI[prop]
					simpleini.set(ini, section, key, value)
			except Exception:
				pass

	simpleini.write(ini, ini_path)

	try:
		rmtree(save_path)
	except Exception:
		pass


def migrate_ini(save_path):
	ini_path = save_path + 'Dashloader.ini'
	if not isfile(ini_path):
		return

	existing = simpleini.load(ini_path)
	ini = simpleini.parse(INI_TEMPLATE, ini_path)

	for section in simpleini.sections(ini):
		if not section:
			continue
		for key, values in simpleini.items(ini, section):
			value = simpleini.get(existing, section, key)
			if value is not None:
				simpleini.set(ini, section, key, value)

	simpleini.write(ini, ini_path)


def install_update(current_xbe, mod_type, do_migration):
	try:
		copy2(NEW_XBE, current_xbe)
		if do_migration:
			legacy_path = SAVE_PATH_LEGACY_SOFTMOD if 'Softmod' in mod_type else SAVE_PATH_LEGACY_HARDMOD
			migrate_legacy(legacy_path, mod_type)
		else:
			migrate_ini(get_ini_save_path(mod_type))
		executebuiltin('Skin.Reset(force_update)')
		executebuiltin('Skin.Reset(dashloader_legacy_declined)')
		executebuiltin('Skin.Reset(dashloader_version_declined)')
		executebuiltin('Skin.Reset(dashloader_declined_version_numb)')
		Dialog().ok(getLocalizedString(31300), '', getLocalizedString(31301), '')
	except Exception:
		Dialog().ok(getLocalizedString(31300), '', getLocalizedString(31302), '')


if ACTION == 'update':
	mod_type = getInfoLabel('Window(10000).Property(modtype)')
	current_xbe = get_current_xbe(mod_type)
	if isfile(NEW_XBE) and current_xbe:
		if Dialog().yesno(
			getLocalizedString(31303),
			'',
			getLocalizedString(31304),
			'',
			getLocalizedString(106),
			getLocalizedString(107)
		):
			do_migration = False
			if isfile(current_xbe):
				try:
					with open(current_xbe, 'rb') as f:
						data = f.read()
					if XBE_SIGNATURE not in data:
						do_migration = True
				except Exception:
					pass

			install_update(current_xbe, mod_type, do_migration = do_migration)
			show_changelog()
			if do_migration:
				executebuiltin('RestartApp')
			else:
				executebuiltin('SetFocus(9001)')
else:
	if STOCK_FOUND and CUSTOM_XBE_PATH:
		executebuiltin('Skin.Reset(CustomXBEPath)')
		Window(10000).setProperty('customxbepath', '')

	if isfile(XBE_PATH_SOFTMOD):
		executebuiltin('SetProperty(ModType,Softmod,10000)')
	elif isfile(XBE_PATH_HARDMOD):
		executebuiltin('SetProperty(ModType,Hardmod,10000)')
	elif CUSTOM_XBE_PATH and isfile(CUSTOM_XBE_PATH):
		Window(10000).setProperty('customxbepath', CUSTOM_XBE_PATH)
		executebuiltin('SetProperty(ModType,Custom,10000)')
	else:
		executebuiltin('SetProperty(ShowError,1,10000)')

	has_xbe_to_check = STOCK_FOUND or (CUSTOM_XBE_PATH and isfile(CUSTOM_XBE_PATH))
	if has_xbe_to_check and isfile(NEW_XBE):
		if CUSTOM_XBE_PATH and isfile(CUSTOM_XBE_PATH) and not STOCK_FOUND:
			mod_type = 'Custom'
		else:
			mod_type = 'Softmod' if isfile(XBE_PATH_SOFTMOD) else 'Hardmod'
		current_xbe = get_current_xbe(mod_type)

		is_legacy_system = False
		is_new_xbe = True
		try:
			with open(current_xbe, 'rb') as f:
				data = f.read()
			if XBE_SIGNATURE not in data:
				is_legacy_system = True
				is_new_xbe = False
			else:
				installed_ver = get_installed_version(current_xbe)
				target_ver = tuple(int(x) for x in XBE_VERSION.split('.'))
				is_new_xbe = installed_ver >= target_ver if installed_ver else False
		except Exception:
			is_new_xbe = True

		should_prompt = False
		decline_setting_to_check = ''

		if is_new_xbe:
			executebuiltin('Skin.Reset(force_update)')
			executebuiltin('Skin.Reset(dashloader_legacy_declined)')
			executebuiltin('Skin.Reset(dashloader_version_declined)')
			executebuiltin('Skin.Reset(dashloader_declined_version_numb)')

		elif is_legacy_system:
			executebuiltin('Skin.Reset(force_update)')
			decline_setting_to_check = 'Skin.HasSetting(dashloader_legacy_declined)'
			if not getCondVisibility(decline_setting_to_check):
				should_prompt = True
		else:
			executebuiltin('Skin.SetBool(force_update)')
			decline_setting_to_check = 'Skin.HasSetting(dashloader_version_declined)'
			declined_ver = getInfoLabel('Skin.String(dashloader_declined_version_numb)')
			if declined_ver != XBE_VERSION:
				executebuiltin('Skin.Reset(dashloader_version_declined)')
				executebuiltin('Skin.Reset(dashloader_declined_version_numb)')
			if not getCondVisibility(decline_setting_to_check):
				should_prompt = True

		if should_prompt:
			if Dialog().yesno(
				getLocalizedString(31305),
				'',
				getLocalizedString(31306),
				'',
				getLocalizedString(106),
				getLocalizedString(107)
			):
				install_update(current_xbe, mod_type, do_migration = is_legacy_system)
				show_changelog()
			else:
				if is_legacy_system:
					executebuiltin('Skin.SetBool(dashloader_legacy_declined)')
				else:
					executebuiltin('Skin.SetBool(dashloader_version_declined)')
					executebuiltin('Skin.SetString(dashloader_declined_version_numb,{})'.format(XBE_VERSION))
				Dialog().ok(getLocalizedString(31305), '', getLocalizedString(31316), '')

	executebuiltin('ActivateWindow(Home)')

	# Keep python loaded. (speeds up all scripts)
	while True:
		sleep(500)
